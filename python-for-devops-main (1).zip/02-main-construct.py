def main():
    folder_paths = input("Enter a list of folder paths separated by spaces: ").split()
    print(folder_paths)

    # Print elements in the list
    #for folder_path in folder_paths:
    #    print(folder_path)

if __name__ == "__main__":
    main()