text = "Python is awesome"
new_text = text.replace("awesome", "great")
print("Modified text:", new_text)
