total = 10

total += 5
total -= 3
total *= 2
total /= 4

print("Final total:", total)
